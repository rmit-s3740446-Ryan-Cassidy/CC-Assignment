# def lambda_handler(event,context):
#     print("Hello")
    
#     return "Thanks"

import boto3
import sys
import logging
import rds_config
import pymysql
s3_client = boto3.client("s3")

#rds settings
rds_host  = "database-1.chyh1wnf7bbo.ap-southeast-2.rds.amazonaws.com"
name = "admin"
password = "cloudpass"
db_name = "gtfs"

# logger = logging.getLogger()
# logger.setLevel(logging.INFO)

# try:
#     conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
# except pymysql.MySQLError as e:
#     logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
#     logger.error(e)
#     sys.exit()

# logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")

def lambda_handler(event,context):
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    s3_file_name = event['Records'][0]['s3']['object']['key']
    resp = s3_client.get_object(Bucket=bucket_name,Key=s3_file_name)
    data=resp['Body'].read().decode("utf-8")
    # print(data)
    print(bucket_name)
    print(s3_file_name)
    stops = data.split("\n")
    # print(stops.len())
    for stop in stops: 
        print(stop)
        stop_data = stop.split(",")
        print(stop_data[2])
        
        # with conn.cursor() as cur:
        #     cur.execute('insert into coords (lat, lon) values(stop_data[1], stop_data[2])')
        #     conn.commit()
   